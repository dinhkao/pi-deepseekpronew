Chay: PYTHONPATH=<repo> python3 song10_the_long_goodbye/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song10_the_long_goodbye/.
