Chay: PYTHONPATH=<repo> python3 song02_paper_face/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song02_paper_face/.
