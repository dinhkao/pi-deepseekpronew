Chay: PYTHONPATH=<repo> python3 song05_every_little_window/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song05_every_little_window/.
