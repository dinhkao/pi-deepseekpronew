Chay: PYTHONPATH=<repo> python3 song03_half_dream_morning/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song03_half_dream_morning/.
