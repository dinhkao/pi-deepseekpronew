Chay: PYTHONPATH=<repo> python3 song04_raga_for_the_restless/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song04_raga_for_the_restless/.
