Chay: PYTHONPATH=<repo> python3 song09_perpetual_motion/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song09_perpetual_motion/.
