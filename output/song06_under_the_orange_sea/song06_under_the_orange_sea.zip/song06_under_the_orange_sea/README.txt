Chay: PYTHONPATH=<repo> python3 song06_under_the_orange_sea/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song06_under_the_orange_sea/.
