Chay: PYTHONPATH=<repo> python3 song01_the_collector/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song01_the_collector/.
