Chay: PYTHONPATH=<repo> python3 song08_sunshower_sunday/main.py
Can: numpy, scipy, ffmpeg va thu vien nhaccu/.
Ra file mp3 + mp3 instrumental vao output/song08_sunshower_sunday/.
